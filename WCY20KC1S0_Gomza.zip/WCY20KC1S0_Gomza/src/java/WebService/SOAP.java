package WebService;

import DB.DBConnect;
import JPA.Wcy20kc1s0Gomza;
import java.sql.Connection;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;


@WebService(serviceName = "SOAP")
public class SOAP {

    DBConnect obj = new DBConnect();
    Connection conn = DBConnect.connect();
    
    @WebMethod(operationName = "display")
    public String display() throws SQLException {
        return Wcy20kc1s0Gomza.display();
    }
    
    @WebMethod(operationName = "insert")
    public void insert(@WebParam(name = "name") String name, @WebParam(name = "file") byte[] file) {
        Wcy20kc1s0Gomza.insert(name, file);
    }
    
    @WebMethod(operationName = "delete")
    public void delete(@WebParam(name = "id") String id) {
        Wcy20kc1s0Gomza.delete(id);
    }
    
    @WebMethod(operationName = "download")
    public void download(@WebParam(name = "id") String id) {
        Wcy20kc1s0Gomza.download(id);
    }
    
}
