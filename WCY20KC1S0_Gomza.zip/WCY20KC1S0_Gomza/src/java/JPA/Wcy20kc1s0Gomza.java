/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JPA;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Paths;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.TypedQuery;
import javax.sql.rowset.serial.SerialBlob;

/**
 *
 * @author student
 */
@Entity
@Table(name = "WCY20KC1S0_GOMZA")
@NamedQueries({
    @NamedQuery(name = "Wcy20kc1s0Gomza.findAll", query = "SELECT w FROM Wcy20kc1s0Gomza w"),
    @NamedQuery(name = "Wcy20kc1s0Gomza.findById", query = "SELECT w FROM Wcy20kc1s0Gomza w WHERE w.id = :id"),
    @NamedQuery(name = "Wcy20kc1s0Gomza.findByName", query = "SELECT w FROM Wcy20kc1s0Gomza w WHERE w.name = :name")})
public class Wcy20kc1s0Gomza implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "NAME")
    private String name;
    @Basic(optional = false)
    @Lob
    @Column(name = "FILE")
    private byte[] file;

    public Wcy20kc1s0Gomza() {
    }

    public Wcy20kc1s0Gomza(Integer id) {
        this.id = id;
    }

    public Wcy20kc1s0Gomza(Integer id, String name, byte[] file) {
        this.id = id;
        this.name = name;
        this.file = file;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getFile() {
        return file;
    }

    public void setFile(byte[] file) {
        this.file = file;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Wcy20kc1s0Gomza)) {
            return false;
        }
        Wcy20kc1s0Gomza other = (Wcy20kc1s0Gomza) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "JPA.Wcy20kc1s0Gomza[ id=" + id + " ]";
    }
    
    public static String display() throws SQLException {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("WCY20KC1S0_GomzaPU");
        EntityManager em = emf.createEntityManager();
        
        TypedQuery<Wcy20kc1s0Gomza> query = em.createNamedQuery("Wcy20kc1s0Gomza.findAll", Wcy20kc1s0Gomza.class);
        List<Wcy20kc1s0Gomza> list = query.getResultList();
        
        String wiersz;  
        String temp,temp2;
        String base64Encoded;
        
        wiersz = ("<table><tr>");  
        
        wiersz = wiersz.concat("<th>ID</th><th>NAME</th><th>PLAY</th><th>ACTION</th>");     
        wiersz = wiersz.concat("</tr>");
        
        for (Wcy20kc1s0Gomza mp4 : list) {            
            wiersz = wiersz.concat("<tr>");
            wiersz = wiersz.concat("<td>" + mp4.getId() + "</td>");
            wiersz = wiersz.concat("<td>" + mp4.getName() + "</td>");
            
            byte[] data = mp4.getFile(); 
            Blob blob = new SerialBlob(data);
                
            int blobLength = (int) blob.length();  
            byte[] blobAsBytes = blob.getBytes(1, blobLength);
            blob.free();
                
            base64Encoded = Base64.getEncoder().encodeToString(blobAsBytes);
                
            wiersz = wiersz.concat("<td><video width=\"320\" height=\"240\" controls><source src=\"data:video/mp4;base64," + base64Encoded + "\" type=\"video/mp4\"></video></td>");
            
            temp = "delete?id=" + mp4.getId();
            temp2 = "download?id=" + mp4.getId();
            wiersz = wiersz.concat("<td><a href="+temp2+"><input type=\"button\" value=\"Download\"></button></a><a style=\"margin-left: 20px\" href="+temp+"><input type=\"button\" value=\"Delete\"></button></a></td>");
            wiersz = wiersz.concat("</tr>");        
        }        
        
        wiersz = wiersz.concat("</table>");
        
        return wiersz;    
    
    }
    
    public static void insert(String nazwa, byte[] mp4){
    
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("WCY20KC1S0_GomzaPU");
        EntityManager em = emf.createEntityManager();   
        em.getTransaction().begin();
        
        TypedQuery<Wcy20kc1s0Gomza> query = em.createNamedQuery("Wcy20kc1s0Gomza.findAll", Wcy20kc1s0Gomza.class);
        List<Wcy20kc1s0Gomza> list = query.getResultList();
             
        int maxid = 0;
        for(Wcy20kc1s0Gomza temp : list){
            maxid = temp.getId();
        }
                      
        Wcy20kc1s0Gomza newmp4 = new Wcy20kc1s0Gomza();    
                   
        newmp4.setId(maxid + 1);
        newmp4.setName(nazwa);
        newmp4.setFile(mp4);
        
        em.persist(newmp4);
        em.flush();
        
        em.getTransaction().commit();  
        em.close();
       
    }
    
    public static void delete(String id){
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("WCY20KC1S0_GomzaPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query query = em.createQuery("DELETE FROM Wcy20kc1s0Gomza w where w.id = :id");
        query.setParameter("id", Integer.valueOf(id)).executeUpdate();
        em.close();

    }
    
    public static void download(String id){
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("WCY20KC1S0_GomzaPU");
        EntityManager em = emf.createEntityManager();

        try {           
            Wcy20kc1s0Gomza file = em.find(Wcy20kc1s0Gomza.class, Integer.valueOf(id));

            if (file != null) {

                byte[] videoBytes = file.getFile(); 

                String homeDirectory = System.getProperty("user.home");
                File outputFile = new File(Paths.get(homeDirectory, "Desktop", file.getName() + ".mp4").toString());

                try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                    fos.write(videoBytes);
                }
            }
        } catch (IOException | NumberFormatException e) {
        } finally {
            em.close();
        }

    }
    
}
